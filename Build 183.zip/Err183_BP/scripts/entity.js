import { world, system } from "@minecraft/server";

const TARGET_ENTITY_IDS = [
    "unknown:sheep_watching",
    "unknown:cow_watching",
    "unknown:chicken_watching",
    "unknown:pig_watching",
    "unknown:183_watching",
    "unknown:183_watching_s2",
    "unknown:183_watching_s4",
    "entity:monster",
    "entity:monster2"
];

const DESPAWN_DISTANCE = 12;
const CHECK_INTERVAL = 5;

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const dimension = player.dimension;

        for (const entityId of TARGET_ENTITY_IDS) {
            const entities = dimension.getEntities({ type: entityId });

            for (const entity of entities) {
                const dx = player.location.x - entity.location.x;
                const dy = player.location.y - entity.location.y;
                const dz = player.location.z - entity.location.z;

                const distanceSq = dx * dx + dy * dy + dz * dz;

                if (distanceSq <= DESPAWN_DISTANCE * DESPAWN_DISTANCE) {
                    entity.remove();
                }
            }
        }
    }
}, CHECK_INTERVAL);