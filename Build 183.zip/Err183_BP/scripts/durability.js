import { world } from "@minecraft/server";

world.afterEvents.playerBreakBlock.subscribe(event => {
    const player = event.player;
    if (!player) return;

    const inventory = player.getComponent("minecraft:inventory");
    if (!inventory) return;

    const container = inventory.container;
    const selectedSlot = player.selectedSlotIndex;
    const item = container.getItem(selectedSlot);

    if (!item) return;

    if (!item.typeId.startsWith("unknown:")) return;

    const durability = item.getComponent("minecraft:durability");
    if (!durability) return;

    durability.damage += 1;

    if (durability.damage >= durability.maxDurability) {
        container.setItem(selectedSlot, undefined);
        player.playSound("random.break");
        return;
    }

    container.setItem(selectedSlot, item);
});