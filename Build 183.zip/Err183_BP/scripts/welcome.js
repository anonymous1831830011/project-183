import { world, system } from "@minecraft/server";

world.afterEvents.worldInitialize.subscribe((event) => {
    const def = event.propertyRegistry;

    def.registerEntityTypeDynamicProperties(
        {
            firstJoin: { type: "boolean", defaultValue: false }
        },
        "minecraft:player"
    );
});

world.afterEvents.playerSpawn.subscribe((event) => {
    const player = event.player;

    if (!event.initialSpawn) return;

    const hasJoinedBefore = player.getDynamicProperty("firstJoin");

    if (!hasJoinedBefore) {
        system.runTimeout(() => {
            player.sendMessage("<???> §o§7Hello, dear adventurer! Welcome to The Forgotten Prototype of Minecraft, also known as Error 183. There are few things I need to tell you. Right now, you're safe. But the more time you spend in this version, the more corrupted it will become. So i highly recommend you to build your base on the sky starting from day 15 or 20. Also beware of the entity in this version. It hates outsiders like you. Before it strikes you, you will see early signs of him standing from a distance watching you. That's all I can tell you. Please remember my advice, you won't regret it. Anyways, have fun.");
        }, 20);

        player.setDynamicProperty("firstJoin", true);
    }
});