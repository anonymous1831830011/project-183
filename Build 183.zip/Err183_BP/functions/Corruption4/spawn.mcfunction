# dummies
summon entity:dummyv2 ~8~45~
summon entity:dummyv2 ~8~45~
summon entity:dummyv2 ~~45~8
summon entity:dummyv2 ~~45~8
summon entity:dummyv2 ~8~45~

# root
setblock ~ ~-1 ~ minecraft:sculk_catalyst

setblock ~2 ~ ~2 minecraft:sculk_catalyst
setblock ~-2 ~ ~-2 minecraft:sculk_catalyst
setblock ~2 ~ ~-2 minecraft:sculk_catalyst
setblock ~-2 ~ ~2 minecraft:sculk_catalyst

# trunk
fill ~-1 ~1 ~-1 ~1 ~25 ~1 minecraft:sculk

# trunk_distortion
fill ~2 ~6 ~-1 ~2 ~12 ~1 minecraft:sculk
fill ~-2 ~10 ~-1 ~-2 ~17 ~1 minecraft:sculk
fill ~-1 ~14 ~2 ~1 ~20 ~2 minecraft:sculk
fill ~-1 ~18 ~-2 ~1 ~23 ~-2 minecraft:sculk

# north branch

# thick base
fill ~-1 ~12 ~-2 ~1 ~13 ~-2 minecraft:sculk

# mid growth (offset + thinner)
fill ~ ~14 ~-3 ~1 ~15 ~-3 minecraft:sculk

# thin extension
setblock ~ ~16 ~-4 minecraft:sculk
setblock ~1 ~17 ~-5 minecraft:sculk

# decay tips
setblock ~1 ~18 ~-6 minecraft:sculk_vein
setblock ~ ~17 ~-4 minecraft:sculk_vein

# east branch

fill ~2 ~15 ~-1 ~2 ~16 ~1 minecraft:sculk
setblock ~3 ~17 ~ minecraft:sculk
setblock ~4 ~18 ~1 minecraft:sculk
setblock ~5 ~19 ~1 minecraft:sculk
setblock ~6 ~20 ~ minecraft:sculk_vein

# west branch

fill ~-2 ~18 ~-1 ~-2 ~19 ~1 minecraft:sculk
setblock ~-3 ~20 ~ minecraft:sculk
setblock ~-4 ~20 ~-1 minecraft:sculk
setblock ~-5 ~19 ~-1 minecraft:sculk_vein

# south branch

fill ~-1 ~10 ~2 ~1 ~11 ~2 minecraft:sculk
setblock ~ ~12 ~3 minecraft:sculk
setblock ~-1 ~13 ~4 minecraft:sculk
setblock ~-1 ~14 ~5 minecraft:sculk_vein

# cancopy

setblock ~ ~23 ~ minecraft:sculk
setblock ~1 ~24 ~ minecraft:sculk
setblock ~-1 ~24 ~ minecraft:sculk
setblock ~ ~24 ~1 minecraft:sculk
setblock ~ ~24 ~-1 minecraft:sculk

setblock ~2 ~25 ~2 minecraft:sculk_vein
setblock ~-2 ~25 ~-2 minecraft:sculk_vein
setblock ~3 ~24 ~ minecraft:sculk_vein

# error183
setblock ~4 ~6 ~-7 unknown:error183

setblock ~-6 ~4 ~9 unknown:error183

setblock ~-10 ~9 ~-10 unknown:error183

setblock ~7 ~12 ~-14 unknown:error183