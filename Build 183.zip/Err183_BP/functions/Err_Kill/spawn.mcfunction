tellraw @a {"rawtext":[{"text":"§c§k9+^])^9})+^*]{*^)*})*^);^9)9^32)0982)790)^0)[9010910109^:)9^2{)}+^9;)2{0^9)}2^390);^90}32)^};09)320^9;)23}^09;)2}3980smily_face.Okwth"}]}

title @a title §l§4GET OUT!!!!

kill @e [type=unknown:entity001]

kill @e [type=zc:headless_zombie]

kill @e [type=entity:emptiness]

kill @e [type=helpus:idont_haveaname]

kill @e [type=zc:steve_068]

kill @e [type=missingname:flesh_eater]