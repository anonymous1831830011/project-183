fog @a push "unknown:cyan_fog_default" "cyan"
fog @a remove "red"
fog @a remove "orange"
fog @a remove "yellow"
fog @a remove "green"
fog @a remove "blue"
fog @a remove "pink"
fog @a remove "white"

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}