setblock ~ ~ ~ nether_wart_block
fill ~-10 ~-10 ~-10 ~10 ~10 ~10 nether_wart_block replace glass_pane
playsound ambient.cave @a ~ ~ ~ 1.0 1.0 1.0
tellraw @a {"rawtext":[{"text":"§cWARNING! - World integrity declining. Unnatural behavior detected. Please check your surroundings."}]}