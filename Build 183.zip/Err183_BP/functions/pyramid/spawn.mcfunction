# Layer 1 (bottom, 5x5)
fill ~-2 ~ ~-2 ~2 ~ ~2 unknown:missing_tile

# Layer 2 (3x3)
fill ~-1 ~1 ~-1 ~1 ~1 ~1 unknown:missing_tile

# Layer 3 (1x1 top block)
setblock ~ ~2 ~ unknown:missing_tile

# Redstone Torch on top
setblock ~ ~3 ~ redstone_torch