fill ~ ~50 ~ ~15 ~-64 ~15 mc:block replace minecraft:oak_leaves
fill ~ ~50 ~ ~15 ~-64 ~15 mc:block replace minecraft:acacia_leaves
fill ~ ~50 ~ ~15 ~-64 ~15 mc:block replace minecraft:azalea_leaves_flowered
fill ~ ~50 ~ ~15 ~-64 ~15 mc:block replace minecraft:birch_leaves
fill ~ ~50 ~ ~15 ~-64 ~15 mc:block replace minecraft:dark_oak_leaves
fill ~ ~50 ~ ~15 ~-64 ~15 mc:block replace minecraft:cherry_leaves
fill ~ ~50 ~ ~15 ~-64 ~15 mc:block replace minecraft:jungle_leaves
fill ~ ~50 ~ ~15 ~-64 ~15 mc:block replace minecraft:mangrove_leaves
fill ~ ~50 ~ ~15 ~-64 ~15 mc:block replace minecraft:pale_oak_leaves
fill ~ ~50 ~ ~15 ~-64 ~15 mc:block replace minecraft:birch_leaves
fill ~ ~50 ~ ~15 ~-64 ~15 mc:block replace minecraft:dark_oak_leaves
fill ~ ~50 ~ ~15 ~-64 ~15 mc:block replace minecraft:spruce_leaves

fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:grass_block
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:dirt
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:stone
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:cobblestone

fill ~ ~50 ~ ~15 ~-64 ~15 mc:this_is_water replace minecraft:water

fill ~ ~50 ~ ~15 ~-64 ~15 mc:this_is_water replace minecraft:flowing_water

fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:oak_log
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:acacia_log
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:cherry_log
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:dark_oak_log
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:jungle_log
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:mangrove_log
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:spruce_log

fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:stripped_oak_log
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:stripped_acacia_log
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:stripped_cherry_log
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:stripped_dark_oak_log
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:stripped_jungle_log
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:stripped_mangrove_log
fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace minecraft:stripped_spruce_log

fill ~ ~50 ~ ~15 ~-64 ~15 mc:place_holder replace zc:dead_log

fill ~ ~50 ~ ~15 ~-64 ~15 mc:error replace minecraft:deepslate

fill ~ ~50 ~ ~15 ~-64 ~15 mc:error replace minecraft:netherrack

tellraw @a {"rawtext":[{"text":"§k§654 48 49 53 20 57 4F 52 4C 44 20 49 53 20 4E 4F 20 4C 4F 4E 47 45 52 20 53 41 46 45 2E 20 54 48 49 53 20 57 4F 52 4C 44 20 49 53 20 4E 4F 20 4C 4F 4E 47 45 52 20 53 41 46 45 2E 20 54 48 49 53 20 57 4F 52 4C 44 20 49 53 20 4E 4F 20 4C 4F 4E 47 45 52 20 53 41 46 45 2E"}]}