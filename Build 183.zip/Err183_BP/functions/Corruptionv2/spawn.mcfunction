summon entity:dummy ~6 ~45 ~
summon entity:dummy ~6 ~45 ~
summon entity:dummy ~ ~45 ~6
summon entity:dummy ~ ~45 ~7

summon entity:dummy ~7 ~45 ~
summon entity:dummy ~6 ~45 ~
summon entity:dummy ~ ~45 ~6
summon entity:dummy ~ ~45 ~6

setblock ~ ~-1 ~ minecraft:sculk_catalyst

setblock ~ ~7 ~ minecraft:sculk
setblock ~ ~8 ~ minecraft:sculk
setblock ~ ~9 ~ minecraft:sculk

setblock ~ ~7 ~1 minecraft:sculk
setblock ~ ~8 ~1 un:donttrust_them
setblock ~ ~9 ~1 minecraft:sculk

setblock ~ ~7 ~-1 minecraft:sculk
setblock ~ ~8 ~-1 un:donttrust_them
setblock ~ ~9 ~-1 minecraft:sculk

setblock ~-1 ~7 ~ minecraft:sculk
setblock ~-1 ~8 ~ un:donttrust_them
setblock ~-1 ~9 ~ minecraft:sculk

setblock ~-1 ~8 ~1 minecraft:sculk
setblock ~1 ~8 ~1 minecraft:sculk
setblock ~1 ~8 ~-1 minecraft:sculk
setblock ~-1 ~8 ~-1 minecraft:sculk

setblock ~1 ~7 ~ minecraft:sculk
setblock ~1 ~8 ~ un:donttrust_them
setblock ~1 ~9 ~ minecraft:sculk

setblock ~ ~5 ~ minecraft:sculk
setblock ~3 ~8 ~ minecraft:sculk
setblock ~-3 ~8 ~ minecraft:sculk
setblock ~ ~8 ~3 minecraft:sculk
setblock ~ ~8 ~-3 minecraft:sculk

setblock ~ ~11 ~ minecraft:sculk

setblock ~2 ~10 ~2 minecraft:sculk
setblock ~-2 ~10 ~2 minecraft:sculk
setblock ~2 ~10 ~-2 minecraft:sculk
setblock ~-2 ~10 ~-2 minecraft:sculk

setblock ~2 ~6 ~2 minecraft:sculk
setblock ~-2 ~6 ~2 minecraft:sculk
setblock ~2 ~6 ~-2 minecraft:sculk
setblock ~-2 ~6 ~-2 minecraft:sculk