tellraw @a {"rawtext":[{"text":"<failed_exp_183> I see you."}]}
clear @a ender_pearl