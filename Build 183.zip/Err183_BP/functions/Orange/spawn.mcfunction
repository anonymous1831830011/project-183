fog @a push "unknown:orange_fog_default" "orange"
fog @a remove "red"
fog @a remove "yellow"
fog @a remove "green"
fog @a remove "cyan"
fog @a remove "blue"
fog @a remove "pink"
fog @a remove "white"

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}