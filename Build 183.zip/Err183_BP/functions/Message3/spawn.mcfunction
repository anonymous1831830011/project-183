setblock ~1 ~-1 ~2 air

setblock ~3 ~-1 ~-3 air

setblock ~1 ~-1 ~2 air

setblock ~-3 ~-1 ~ mc:error

setblock ~1 ~-1 ~-1 air

setblock ~ ~-1 ~6 air

setblock ~ ~-1 ~-3 unknown:missing_tile

setblock ~ ~ ~5 mc:error

setblock ~-5 ~1 ~-1 un:donttrust_them

setblock ~2 ~-1 ~-4 zc:weird_netherrack

setblock ~ ~-1 ~-2 air

setblock ~-3 ~1 ~-4 zc:weird_netherrack

setblock ~-2 ~3 ~4 air

setblock ~-3 ~1 ~-2 zc:weird_netherrack

setblock ~-1 ~3 ~-4 unknown:corrupted_air

fill ~-12 ~ ~-12 ~12 ~ ~12 mc:block replace minecraft:oak_leaves

fill ~-12 ~ ~-12 ~12 ~ ~12 mc:block replace minecraft:jungle_leaves

fill ~-12 ~ ~-12 ~12 ~ ~12 mc:block replace minecraft:cherry_leaves

fill ~-12 ~ ~-12 ~12 ~ ~12 mc:block replace minecraft:acacia_leaves

fill ~-12 ~ ~-12 ~12 ~ ~12 mc:block replace minecraft:birch_leaves

fill ~-12 ~ ~-12 ~12 ~ ~12 mc:block replace minecraft:spruce_leaves

fill ~-12 ~ ~-12 ~12 ~ ~12 mc:block replace minecraft:dark_oak_leaves

fill ~-12 ~ ~-12 ~12 ~ ~12 mc:place_holder replace minecraft:short_grass

fill ~-12 ~ ~-12 ~12 ~ ~12 mc:this_is_water replace minecraft:water

fill ~-12 ~ ~-12 ~12 ~ ~12 mc:place_holder replace minecraft:tall_grass

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}

title @a title §l§4Вам не следует здесь находиться…

tp @s @e [type=unknown:failed_exp_183]

effect @a clear