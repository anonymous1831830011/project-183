playsound ambient.cave @a ~ ~ ~ 1.0 1.0 1.0
tellraw @a {"rawtext":[{"text":"§cNearby corruption detected. Please leave the area immediately."}]}