summon entity:dummyv2 ~3~45~5
summon entity:dummyv2 ~4~45~5
summon entity:dummyv2 ~~45~6
summon entity:dummyv2 ~~45~5
summon entity:dummyv2 ~3~45~5
summon entity:dummyv2 ~3~45~5
summon entity:dummy ~~45~6
summon entity:dummy ~~45~6
summon entity:dummy ~3~45~5
summon entity:dummy ~4~45~5
summon entity:dummy ~~45~5
fill ~-1 ~ ~-1 ~1 ~10 ~1 sculk
fill ~0 ~1 ~0 ~0 ~9 ~0 air
setblock ~3 ~9 ~ sculk
setblock ~-3 ~9 ~ sculk
setblock ~ ~9 ~3 sculk
setblock ~ ~9 ~-3 sculk
setblock ~2 ~10 ~2 sculk
setblock ~-2 ~10 ~-2 sculk
setblock ~2 ~10 ~-2 sculk
setblock ~-2 ~10 ~2 sculk
setblock ~4 ~8 ~ sculk
setblock ~ ~8 ~4 sculk
setblock ~-4 ~8 ~ sculk
setblock ~ ~8 ~-4 sculk
setblock ~2 ~-1 ~ sculk_catalyst
setblock ~-2 ~-1 ~ sculk_catalyst
setblock ~ ~-1 ~2 sculk_catalyst
setblock ~ ~-1 ~-2 sculk_catalyst
setblock ~1 ~-1 ~1 sculk_catalyst
setblock ~-1 ~-1 ~-1 sculk_catalyst
setblock ~1 ~9 ~1 sculk_vein
setblock ~-1 ~9 ~-1 sculk_vein
setblock ~1 ~9 ~-1 sculk_vein
setblock ~-1 ~11 ~1 sculk_vein
setblock ~ ~10 ~2 sculk
setblock ~ ~10 ~-2 sculk
setblock ~2 ~10 ~ sculk
setblock ~-2 ~10 ~ sculk
setblock ~ ~11 ~ un:donttrust_them

# error183
setblock ~3 ~6 ~7 unknown:error183

setblock ~-2 ~5 ~-7 unknown:error183