fog @a push "unknown:blue_fog_default" "blue"
fog @a remove "red"
fog @a remove "orange"
fog @a remove "yellow"
fog @a remove "green"
fog @a remove "cyan"
fog @a remove "pink"
fog @a remove "white"

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}