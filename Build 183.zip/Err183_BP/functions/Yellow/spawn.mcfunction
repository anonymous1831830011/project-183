fog @a push "unknown:yellow_fog_default" "yellow"
fog @a remove "red"
fog @a remove "orange"
fog @a remove "green"
fog @a remove "cyan"
fog @a remove "blue"
fog @a remove "pink"
fog @a remove "white"

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}