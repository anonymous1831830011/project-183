fill ~ ~-8 ~ ~7 ~-1 ~7 unknown:missing_tile
tellraw @a {"rawtext":[{"text":"§k§lOh_youFoundThisMessage!Congratulations!JesusLovesYou."}]}