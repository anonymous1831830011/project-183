setblock ~1 ~-1 ~2 air

setblock ~3 ~-1 ~-3 air

setblock ~1 ~-1 ~2 air

setblock ~-3 ~-1 ~ mc:error

setblock ~5 ~3 ~-1 unknown:rgb

setblock ~-4 ~2 ~-4 unknown:debug

setblock ~6 ~7 ~10 unknown:debug2

setblock ~-4 ~3 ~6 unknown:error404

setblock ~1 ~-1 ~-1 air

setblock ~ ~-1 ~6 air

setblock ~ ~-1 ~-3 unknown:missing_tile

setblock ~ ~ ~5 mc:error

setblock ~-5 ~1 ~-1 un:donttrust_them

setblock ~2 ~-1 ~-4 zc:weird_netherrack

setblock ~ ~-1 ~-2 air

fill ~-10 ~-1 ~-10 ~10 ~-1 ~10 mc:error replace minecraft:oak_leaves

fill ~-10 ~-1 ~-10 ~10 ~-1 ~10 mc:error replace minecraft:birch_leaves

fill ~-10 ~-1 ~-10 ~10 ~-1 ~10 mc:error replace minecraft:spruce_leaves

fill ~-10 ~-1 ~-10 ~10 ~-1 ~10 mc:error replace minecraft:acacia_leaves

fill ~-10 ~-1 ~-10 ~10 ~-1 ~10 mc:error replace minecraft:cherry_leaves

fill ~-10 ~-1 ~-10 ~10 ~-1 ~10 mc:error replace minecraft:jungle_leaves

fill ~-10 ~-1 ~-10 ~10 ~-1 ~10 mc:error replace minecraft:dark_oak_leaves

fill ~-10 ~-1 ~-10 ~10 ~-1 ~10 mc:place_holder replace minecraft:short_grass

fill ~-10 ~-1 ~-10 ~10 ~-1 ~10 mc:this_is_water replace minecraft:water

fill ~-10 ~-1 ~-10 ~10 ~-1 ~10 mc:place_holder replace minecraft:tall_grass

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}

title @a title §l§4你不因该来这里…

tp @s @e [type=unknown:failed_exp_183]

effect @a night_vision 9999