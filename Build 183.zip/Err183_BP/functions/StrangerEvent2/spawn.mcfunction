summon helpus:faceless_people ~ ~ ~-1
summon helpus:faceless_people ~ ~ ~2
summon helpus:faceless_people ~ ~ ~1
summon zc:steve_068 ~2 ~ ~
summon zc:steve_068 ~-1 ~ ~
summon zc:steve_068 ~ ~ ~
summon unknown:cultist ~1 ~ ~
summon unknown:cultist ~ ~ ~
summon unknown:cultist ~ ~ ~2
summon unknown:cultist2 ~ ~ ~1
summon unknown:cultist2 ~ ~ ~-1
summon unknown:cultist2 ~-2 ~ ~
summon unknown:cult_leader ~ ~ ~
setblock ~ ~ ~ un:donttrust_them
playsound ambient.cave @a 0 0 0 999999 1 1
tellraw @a {"rawtext":[{"text":"§l§4die die die die die die die die die die die die die die die die die die die die die die die"}]}