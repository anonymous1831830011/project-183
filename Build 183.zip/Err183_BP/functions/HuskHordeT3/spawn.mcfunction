setblock ~10 ~ ~-15 standing_sign

tellraw @a {"rawtext":[{"text":"§eplayer003 joined the game."}]}