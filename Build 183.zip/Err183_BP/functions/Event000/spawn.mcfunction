summon unknown:entity001 ~2 ~ ~3
summon unknown:entity001 ~1 ~ ~-3
summon zc:headless_zombie ~ ~ ~4
summon entity:emptiness ~-3 ~ ~-3
summon helpus:idont_haveaname ~-2 ~ ~3
summon zc:steve_068 ~-1 ~ ~-1
summon missingname:flesh_eater ~-2 ~ ~-2