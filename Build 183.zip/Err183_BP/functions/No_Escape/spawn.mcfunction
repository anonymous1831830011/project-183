fill ~-10 ~-10 ~-10 ~10 ~10 ~10 un:donttrust_them replace end_portal

fill ~-10 ~-10 ~-10 ~10 ~10 ~10 unknown:error404 replace bedrock

fill ~-10 ~-10 ~-10 ~10 ~10 ~10 air replace torch