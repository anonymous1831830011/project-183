summon zc:steve_068 ~ ~ ~

summon zc:steve_068 ~-1 ~ ~

summon zc:steve_068 ~1 ~ ~

summon zc:player1 ~2 ~ ~

summon zc:player2 ~3 ~ ~-1

summon zc:player3 ~-2 ~ ~

summon zc:player4 ~-2 ~ ~1

summon helpus:faceless_people ~-4 ~ ~