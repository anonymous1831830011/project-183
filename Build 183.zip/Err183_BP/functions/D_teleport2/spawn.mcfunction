tp @p 0 90 0
kick @p