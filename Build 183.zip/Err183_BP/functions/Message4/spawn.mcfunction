setblock ~1 ~-1 ~2 air

setblock ~3 ~-1 ~-3 air

setblock ~1 ~-1 ~2 air

setblock ~-3 ~-1 ~ mc:error

setblock ~6 ~2 ~-1 unknown:rgb 

setblock ~-6 ~4 ~2 unknown:rgb

setblock ~--1 ~2 ~-4 unknown:debug

setblock ~-2 ~5 ~8 unknown:debug2

setblock ~3 ~4 ~-1 unknown:error404

setblock ~1 ~2 ~1 unknown:error404

setblock ~1 ~-1 ~-1 air

setblock ~ ~-1 ~6 air

setblock ~ ~1 ~4 zc:glowing_obsidian

setblock ~-5 ~1 ~-1 un:donttrust_them

setblock ~2 ~-1 ~3 zc:weird_netherrack

setblock ~ ~-1 ~-2 air

setblock ~-2 ~3 ~4 air

setblock ~-3 ~1 ~-2 zc:weird_netherrack

setblock ~ ~-1 ~-5 air

setblock ~ ~2 ~-5 lava

fill ~-14 ~ ~-14 ~15 ~ ~15 un:donttrust_them replace minecraft:oak_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 un:donttrust_them replace minecraft:jungle_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 un:donttrust_them replace minecraft:acacia_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 un:donttrust_them replace minecraft:cherry_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 un:donttrust_them replace minecraft:birch_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 un:donttrust_them replace minecraft:spruce_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 un:donttrust_them replace minecraft:dark_oak_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 mc:place_holder replace minecraft:short_grass

fill ~-14 ~ ~-14 ~15 ~ ~15 mc:this_is_water replace minecraft:water

fill ~-14 ~ ~-14 ~15 ~ ~15 mc:place_holder replace minecraft:tall_grass

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}

title @a title §l§4あなたはここにいるべきではない…

effect @a night_vision 9999