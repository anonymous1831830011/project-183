fog @a push "event:thick_fog_default" event
playsound ambient.cave @a 0 0 0 999999 1 1
tellraw @a {"rawtext":[{"text":"§k§o121 111 117 32 99 97 110 39 116 32 108 105 118 101 32 102 111 114 101 118 101 114"}]}