give @a bedrock 964
playsound ambient.cave @a ~ ~ ~ 1