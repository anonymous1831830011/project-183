fill ~-10 ~-10 ~-10 ~10 ~10 ~10 nether_wart_block replace glass_pane
fill ~-10 ~-10 ~-10 ~10 ~10 ~10 redstone_torch replace torch
fill ~-10 ~-10 ~-10 ~10 ~10 ~10 netherrack replace cobblestone
fill ~-10 ~-10 ~-10 ~10 ~10 ~10 netherrack replace mossy_cobblestone
fill ~-10 ~-10 ~-10 ~10 ~10 ~10 nether_brick replace stripped_oak_log
fill ~-10 ~-10 ~-10 ~10 ~10 ~10 nether_brick replace stripped_spruce_log
fill ~-10 ~-10 ~-10 ~10 ~10 ~10 nether_brick replace oak_planks
fill ~-10 ~-10 ~-10 ~10 ~10 ~10 red_nether_brick replace white_terracotta
kill @e [type=villager]
kill @e [type=iron_golem]