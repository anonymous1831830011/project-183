setblock ~1 ~-1 ~2 air

setblock ~-1 ~3 ~-4 waterlily

setblock ~3 ~-1 ~-3 air

setblock ~1 ~-1 ~2 air

setblock ~-3 ~-1 ~ mc:error

setblock ~1 ~-1 ~-1 air

setblock ~ ~-1 ~6 air

setblock ~ ~-1 ~-3 unknown:missing_tile

fill ~-7 ~-1 ~-7 ~7 ~-1 ~7 mc:block replace minecraft:oak_leaves

fill ~-7 ~-1 ~-7 ~7 ~-1 ~7 mc:place_holder replace minecraft:acacia_leaves

fill ~-7 ~-1 ~-7 ~7 ~-1 ~7 mc:place_holder replace minecraft:cherry_leaves

fill ~-7 ~-1 ~-7 ~7 ~-1 ~7 mc:place_holder replace minecraft:jungle_leaves

fill ~-7 ~-1 ~-7 ~7 ~-1 ~7 mc:place_holder replace minecraft:short_grass

fill ~-7 ~-1 ~-7 ~7 ~-1 ~7 mc:this_is_water replace minecraft:water

fill ~-7 ~-1 ~-7 ~7 ~-1 ~7 mc:place_holder replace minecraft:tall_grass

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}

title @a title §l§4Tu ne devrais pas être ici…

tp @s @e [type=unknown:failed_exp_183]

effect @a clear