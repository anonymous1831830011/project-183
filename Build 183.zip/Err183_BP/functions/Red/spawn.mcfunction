fog @a push "unknown:red_fog_default" "red"
fog @a remove "orange"
fog @a remove "yellow"
fog @a remove "green"
fog @a remove "cyan"
fog @a remove "blue"
fog @a remove "pink"
fog @a remove "white"

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}