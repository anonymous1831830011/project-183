camerashake add @a 0.5 30 positional
tp @e[type=unknown:failed_exp_183] @p