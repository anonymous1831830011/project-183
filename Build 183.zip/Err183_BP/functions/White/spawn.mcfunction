fog @a push "unknown:white_fog_default" "white"
fog @a remove "red"
fog @a remove "orange"
fog @a remove "yellow"
fog @a remove "green"
fog @a remove "cyan"
fog @a remove "blue"
fog @a remove "pink"

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}