fog @a push "unknown:pink_fog_default" "pink"
fog @a remove "red"
fog @a remove "orange"
fog @a remove "yellow"
fog @a remove "green"
fog @a remove "cyan"
fog @a remove "blue"
fog @a remove "white"

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}