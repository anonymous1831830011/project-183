setblock ~-1 ~-1 ~2 unknown:missing_tile

setblock ~ ~-1 ~ unknown:missing_tile

setblock ~2 ~-1 ~-1 unknown:missing_tile

setblock ~3 ~2 ~-3 mc:error

setblock ~-3 ~-1 ~-2 air

fill ~-5 ~ ~-5 ~4 ~ ~4 mc:error replace minecraft:oak_planks

fill ~-5 ~ ~-5 ~4 ~ ~4 mc:block replace minecraft:oak_leaves

fill ~-5 ~ ~-5 ~4 ~ ~4 mc:block replace minecraft:cherry_leaves

fill ~-5 ~ ~-5 ~4 ~ ~4 mc:block replace minecraft:jungle_leaves

fill ~-5 ~ ~-5 ~4 ~ ~4 mc:place_holder replace minecraft:cobblestone

fill ~-5 ~ ~-5 ~4 ~ ~4 mc:place_holder replace minecraft:short_grass

fill ~-5 ~ ~-5 ~4 ~ ~4 mc:this_is_water replace minecraft:water

fill ~-5 ~ ~-5 ~4 ~ ~4 mc:place_holder replace minecraft:tall_grass

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}

title @a title §l§4You shouldn't be here…

effect @a night_vision 9999