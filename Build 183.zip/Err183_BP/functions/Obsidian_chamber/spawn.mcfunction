fill ~-15 ~ ~-15 ~15 ~30 ~15 obsidian hollow
effect @s night_vision infinite