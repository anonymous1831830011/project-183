fill ~ ~-8 ~ ~7 ~-1 ~7 unknown:rgb
tellraw @a {"rawtext":[{"text":"die"}]}