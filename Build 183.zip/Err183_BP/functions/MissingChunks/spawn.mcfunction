fill ~ ~50 ~ ~15 ~-64 ~15 air
tellraw @a {"rawtext":[{"text":"§k§lOh_youFoundThisMessage!Congratulations!JesusLovesYou."}]}