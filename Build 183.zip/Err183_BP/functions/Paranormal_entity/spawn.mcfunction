summon entity:monster ~-3 ~1 ~
summon entity:monster2 ~3 ~1 ~
setblock ~ ~ ~ un:donttrust_them