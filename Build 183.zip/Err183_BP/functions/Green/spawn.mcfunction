fog @a push "unknown:green_fog_default" "green"
fog @a remove "red"
fog @a remove "orange"
fog @a remove "yellow"
fog @a remove "cyan"
fog @a remove "blue"
fog @a remove "pink"
fog @a remove "white"

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}