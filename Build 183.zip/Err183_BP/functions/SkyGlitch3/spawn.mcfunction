fill ~ ~-8 ~ ~7 ~-1 ~7 mc:error
tellraw @a {"rawtext":[{"text":"die"}]}