summon entity:dummyv2 ~8~45~
summon entity:dummyv2 ~8~45~
summon entity:dummyv2 ~~45~8
summon entity:dummyv2 ~~45~8
summon entity:dummyv2 ~8~45~
summon entity:dummyv2 ~8~45~

# Giant 2x2 trunk, hollow core (from y=0 to y=15)
setblock ~1 ~15 ~1 sculk
setblock ~1 ~14 ~1 sculk
setblock ~1 ~13 ~1 sculk
setblock ~1 ~12 ~1 sculk
setblock ~1 ~11 ~1 sculk
setblock ~1 ~10 ~1 sculk
setblock ~1 ~9 ~1 sculk
setblock ~1 ~8 ~1 sculk
setblock ~1 ~7 ~1 sculk
setblock ~1 ~6 ~1 sculk
setblock ~1 ~5 ~1 sculk
setblock ~1 ~4 ~1 sculk
setblock ~1 ~3 ~1 sculk
setblock ~1 ~2 ~1 sculk
setblock ~1 ~1 ~1 sculk
setblock ~1 ~ ~1 sculk

setblock ~ ~15 ~1 sculk
setblock ~ ~14 ~1 sculk
setblock ~ ~13 ~1 sculk
setblock ~ ~12 ~1 sculk
setblock ~ ~11 ~1 sculk
setblock ~ ~10 ~1 sculk
setblock ~ ~9 ~1 sculk
setblock ~ ~8 ~1 sculk
setblock ~ ~7 ~1 sculk
setblock ~ ~6 ~1 sculk
setblock ~ ~5 ~1 sculk
setblock ~ ~4 ~1 sculk
setblock ~ ~3 ~1 sculk
setblock ~ ~2 ~1 sculk
setblock ~ ~1 ~1 sculk
setblock ~1 ~ ~1 sculk

setblock ~-1 ~15 ~1 sculk
setblock ~-1 ~14 ~1 sculk
setblock ~-1 ~13 ~1 sculk
setblock ~-1 ~12 ~1 sculk
setblock ~-1 ~11 ~1 sculk
setblock ~-1 ~10 ~1 sculk
setblock ~-1 ~9 ~1 sculk
setblock ~-1 ~8 ~1 sculk
setblock ~-1 ~7 ~1 sculk
setblock ~-1 ~6 ~1 sculk
setblock ~-1 ~5 ~1 sculk
setblock ~-1 ~4 ~1 sculk
setblock ~-1 ~3 ~1 sculk
setblock ~-1 ~2 ~1 sculk
setblock ~-1 ~1 ~1 sculk
setblock ~-1 ~ ~1 sculk

# Giant 2x2 trunk, hollow core (from y=0 to y=15)
setblock ~1 ~15 ~ sculk
setblock ~1 ~14 ~ sculk
setblock ~1 ~13 ~ sculk
setblock ~1 ~12 ~ sculk
setblock ~1 ~11 ~ sculk
setblock ~1 ~10 ~ sculk
setblock ~1 ~9 ~ sculk
setblock ~1 ~8 ~ sculk
setblock ~1 ~7 ~ sculk
setblock ~1 ~6 ~ sculk
setblock ~1 ~5 ~ sculk
setblock ~1 ~4 ~ sculk
setblock ~1 ~3 ~ sculk
setblock ~1 ~2 ~ sculk
setblock ~1 ~1 ~ sculk
setblock ~1 ~ ~ sculk

setblock ~ ~15 ~ sculk
setblock ~ ~14 ~ sculk
setblock ~ ~13 ~ sculk
setblock ~ ~12 ~ sculk
setblock ~ ~11 ~ sculk
setblock ~ ~10 ~ sculk
setblock ~ ~9 ~ sculk
setblock ~ ~8 ~ sculk
setblock ~ ~7 ~ sculk
setblock ~ ~6 ~ sculk
setblock ~ ~5 ~ sculk
setblock ~ ~4 ~ sculk
setblock ~ ~3 ~ sculk
setblock ~ ~2 ~ sculk
setblock ~ ~1 ~ sculk
setblock ~1 ~ ~ sculk

setblock ~-1 ~15 ~ sculk
setblock ~-1 ~14 ~ sculk
setblock ~-1 ~13 ~ sculk
setblock ~-1 ~12 ~ sculk
setblock ~-1 ~11 ~ sculk
setblock ~-1 ~10 ~ sculk
setblock ~-1 ~9 ~ sculk
setblock ~-1 ~8 ~ sculk
setblock ~-1 ~7 ~ sculk
setblock ~-1 ~6 ~ sculk
setblock ~-1 ~5 ~ sculk
setblock ~-1 ~4 ~ sculk
setblock ~-1 ~3 ~ sculk
setblock ~-1 ~2 ~ sculk
setblock ~-1 ~1 ~ sculk
setblock ~-1 ~ ~ sculk

# Giant 2x2 trunk, hollow core (from y=0 to y=15)
setblock ~1 ~15 ~-1 sculk
setblock ~1 ~14 ~-1 sculk
setblock ~1 ~13 ~-1 sculk
setblock ~1 ~12 ~-1 sculk
setblock ~1 ~11 ~-1 sculk
setblock ~1 ~10 ~-1 sculk
setblock ~1 ~9 ~-1 sculk
setblock ~1 ~8 ~-1 sculk
setblock ~1 ~7 ~-1 sculk
setblock ~1 ~6 ~-1 sculk
setblock ~1 ~5 ~-1 sculk
setblock ~1 ~4 ~-1 sculk
setblock ~1 ~3 ~-1 sculk
setblock ~1 ~2 ~-1 sculk
setblock ~1 ~1 ~-1 sculk
setblock ~1 ~ ~-1 sculk

setblock ~ ~15 ~-1 sculk
setblock ~ ~14 ~-1 sculk
setblock ~ ~13 ~-1 sculk
setblock ~ ~12 ~-1 sculk
setblock ~ ~11 ~-1 sculk
setblock ~ ~10 ~-1 sculk
setblock ~ ~9 ~-1 sculk
setblock ~ ~8 ~-1 sculk
setblock ~ ~7 ~-1 sculk
setblock ~ ~6 ~-1 sculk
setblock ~ ~5 ~-1 sculk
setblock ~ ~4 ~-1 sculk
setblock ~ ~3 ~-1 sculk
setblock ~ ~2 ~-1 sculk
setblock ~ ~1 ~-1 sculk
setblock ~1 ~ ~-1 sculk

setblock ~-1 ~15 ~-1 sculk
setblock ~-1 ~14 ~-1 sculk
setblock ~-1 ~13 ~-1 sculk
setblock ~-1 ~12 ~-1 sculk
setblock ~-1 ~11 ~-1 sculk
setblock ~-1 ~10 ~-1 sculk
setblock ~-1 ~9 ~-1 sculk
setblock ~-1 ~8 ~-1 sculk
setblock ~-1 ~7 ~-1 sculk
setblock ~-1 ~6 ~-1 sculk
setblock ~-1 ~5 ~-1 sculk
setblock ~-1 ~4 ~-1 sculk
setblock ~-1 ~3 ~-1 sculk
setblock ~-1 ~2 ~-1 sculk
setblock ~-1 ~1 ~-1 sculk
setblock ~-1 ~ ~-1 sculk

setblock ~ ~17 ~ sculk

# Branches extending at different heights (sculk)
setblock ~3 ~13 ~ sculk
setblock ~-3 ~12 ~ sculk
setblock ~ ~13 ~3 sculk
setblock ~ ~12 ~-3 sculk

setblock ~4 ~14 ~1 sculk
setblock ~-4 ~13 ~ sculk
setblock ~1 ~13 ~-4 sculk
setblock ~-1 ~14 ~4 sculk

# Branch tops
setblock ~5 ~15 ~ sculk
setblock ~ ~15 ~5 sculk
setblock ~-5 ~15 ~ sculk
setblock ~ ~15 ~-5 sculk

# Some twisted hanging parts
setblock ~2 ~11 ~2 sculk
setblock ~-2 ~11 ~-2 sculk
setblock ~2 ~10 ~-2 sculk
setblock ~-2 ~10 ~2 sculk
setblock ~2 ~12 ~ sculk
setblock ~ ~12 ~2 sculk
setblock ~-2 ~11 ~ sculk
setblock ~ ~11 ~-2 sculk
setblock ~-4 ~14 ~ sculk

# Roots / ground corruption (catalyst)
setblock ~2 ~-1 ~ sculk_catalyst
setblock ~-2 ~-1 ~ sculk_catalyst
setblock ~ ~-1 ~2 sculk_catalyst
setblock ~ ~-1 ~-2 sculk_catalyst
setblock ~1 ~-1 ~1 sculk_catalyst
setblock ~-1 ~-1 ~-1 sculk_catalyst

# Optional sculk veins for organic effect
setblock ~1 ~15 ~ sculk_vein
setblock ~-1 ~14 ~1 sculk_vein
setblock ~1 ~13 ~-1 sculk_vein
setblock ~-1 ~12 ~-1 sculk_vein

# eerie sound
playsound ambient.cave @a ~ ~ ~ 1000 1 1

# error183
setblock ~2 ~6 ~10 unknown:error183

setblock ~-6 ~8 ~8 unknown:error183

setblock ~7 ~5 ~-7 unknown:error183