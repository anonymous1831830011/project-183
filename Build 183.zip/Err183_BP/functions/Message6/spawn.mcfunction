setblock ~-1 ~-1 ~3 air

setblock ~1 ~4 ~1 waterlily

setblock ~-3 ~ ~-6 waterlily

setblock ~-3 ~-1 ~3 air

setblock ~-6 ~2 ~-1 unknown:rgb

setblock ~10 ~4 ~-4 unknown:rgb

setblock ~6 ~2 ~-1 unknown:debug

setblock ~-2 ~2 ~-9 unknown:debug2

setblock ~-1 ~-1 ~3 air

setblock ~-3 ~-1 ~ mc:error

setblock ~1 ~-1 ~-1 air

setblock ~ ~-1 ~6 air

setblock ~2 ~1 ~-6 zc:glowing_obsidian

setblock ~ ~2 ~-3 un:donttrust_them

setblock ~1 ~ ~-3 zc:weird_netherrack

setblock ~ ~-1 ~3 air

setblock ~-2 ~-1 ~-1 air

setblock ~2 ~2 ~-1zc:weird_netherrack

setblock ~1 ~-1 ~-5 air

setblock ~ ~-1 ~1 lava

setblock ~ ~2 ~3 lava

setblock ~-2 ~2 ~2 water

setblock ~2 ~2 ~6 unknown:corrupted_air

fill ~-14 ~ ~-14 ~15 ~ ~15 zc:weird_netherrack replace minecraft:oak_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 zc:weird_netherrack replace minecraft:jungle_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 zc:weird_netherrack replace minecraft:acacia_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 zc:weird_netherrack replace minecraft:cherry_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 zc:weird_netherrack replace minecraft:birch_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 zc:weird_netherrack replace minecraft:spruce_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 zc:weird_netherrack replace minecraft:dark_oak_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 mc:error replace minecraft:short_grass

fill ~-14 ~ ~-14 ~15 ~ ~15 mc:this_is_water replace minecraft:water

fill ~-14 ~ ~-14 ~15 ~ ~15 mc:place_holder replace minecraft:tall_grass

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}

title @a title §l§4Kamu seharusnya tidak berada di sini…

effect @a weakness 60 3

tp @e[type=unknown:failed_exp_183] @p

tp @e[type=unknown:failed_exp_183_stage2] @p

tp @e[type=unknown:failed_exp_183_stage3] @p

tp @e[type=unknown:failed_exp_183_stage4] @p