summon entity:dummy ~4~45~
summon entity:dummy ~4~45~
summon entity:dummy ~~45~4
summon entity:dummy ~~45~4
summon entity:dummy ~4~45~
summon entity:dummy ~4~45~
summon entity:dummy ~~45~4
summon entity:dummy ~~45~4
summon entity:dummy ~7~45~
summon entity:dummy ~7~45~
summon entity:dummy ~~45~7
summon entity:dummy g ~~45~7
summon entity:dummy ~7~45~
summon entity:dummy ~8~45~
summon entity:dummy ~~45~6
fill ~ ~ ~ ~ ~7 ~ sculk_catalyst
setblock ~1 ~5 ~ sculk
setblock ~-1 ~6 ~ sculk
setblock ~ ~6 ~1 sculk
setblock ~ ~7 ~-1 sculk
setblock ~1 ~ ~ sculk
setblock ~-1 ~ ~ sculk
setblock ~ ~ ~1 sculk
setblock ~ ~ ~-1 sculk
setblock ~1 ~6 ~ sculk_vein
setblock ~-1 ~5 ~ sculk_vein
setblock ~ ~7 ~1 sculk_vein
setblock ~ ~6 ~-1 sculk_vein

# error183
setblock ~3 ~7 ~8 unknown:error183

setblock ~-2 ~5 ~11 unknown:error183