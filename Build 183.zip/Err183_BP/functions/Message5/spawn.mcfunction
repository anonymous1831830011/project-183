setblock ~1 ~-1 ~2 air

setblock ~-1 ~4 ~1 waterlily

setblock ~3 ~-1 ~-3 air

setblock ~1 ~-1 ~2 air

setblock ~-3 ~-1 ~ mc:error

setblock ~1 ~-1 ~-1 air

setblock ~ ~-1 ~6 air

setblock ~3 ~2 ~ zc:glowing_obsidian

setblock ~-4 ~1 ~ un:donttrust_them

setblock ~2 ~-1 ~3 zc:weird_netherrack

setblock ~ ~-1 ~-3 air

setblock ~-1 ~3 ~4 air

setblock ~-2 ~2 ~-1zc:weird_netherrack

setblock ~1 ~-1 ~-5 air

setblock ~ ~2 ~-5 lava

setblock ~1 ~1 ~-3 lava

setblock ~4 ~1 ~-2 water

fill ~-14 ~ ~-14 ~15 ~ ~15 zc:weird_netherrack replace minecraft:oak_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 zc:weird_netherrack replace minecraft:jungle_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 zc:weird_netherrack replace minecraft:acacia_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 zc:weird_netherrack replace minecraft:cherry_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 zc:weird_netherrack replace minecraft:birch_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 zc:weird_netherrack replace minecraft:spruce_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 zc:weird_netherrack replace minecraft:dark_oak_leaves

fill ~-14 ~ ~-14 ~15 ~ ~15 mc:error replace minecraft:short_grass

fill ~-14 ~ ~-14 ~15 ~ ~15 mc:this_is_water replace minecraft:water

fill ~-14 ~ ~-14 ~15 ~ ~15 mc:place_holder replace minecraft:tall_grass

tellraw @a {"rawtext":[{"text":"§4§lRUN."}]}

title @a title §l§4Hindi ka dapat nandito...

effect @a clear