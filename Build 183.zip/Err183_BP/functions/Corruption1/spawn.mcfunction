summon entity:dummy ~2~45~
summon entity:dummy ~3~45~
summon entity:dummy ~~45~2
summon entity:dummy ~~45~3
summon entity:dummy ~2~45~
summon entity:dummy ~3~45~
summon entity:dummy ~~45~2
summon entity:dummy ~~45~3
summon entity:dummy ~3~45~
summon entity:dummy ~4~45~
setblock ~~-1~ minecraft:sculk_catalyst

# error183
setblock ~-7 ~7 ~9 unknown:error183