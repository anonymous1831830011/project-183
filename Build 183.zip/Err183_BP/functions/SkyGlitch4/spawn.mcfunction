fill ~ ~-8 ~ ~7 ~-1 ~7 unknown:error404
tellraw @a {"rawtext":[{"text":"die"}]}