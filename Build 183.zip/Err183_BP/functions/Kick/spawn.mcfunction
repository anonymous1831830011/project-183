setblock ~ ~ ~ bedrock
tp @p 29999990 90 29999990
kick @a